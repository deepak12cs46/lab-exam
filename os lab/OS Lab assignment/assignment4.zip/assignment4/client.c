/* Roll No:  12/CS/39, 12/CS/40
 * Name:     Soumyadip Mitra, Saikat Kumar Dey
 * Group No: 19 
 */
 
#include<sys/types.h>
#include<sys/wait.h>
#include<sys/ipc.h>
#include<sys/msg.h>
#include<stdio.h>
#include<stdlib.h>
#include<string.h>
#define MSGSIZE 256
#define PERMS 0666
struct message {
	long int mtype;
	char mtext[MSGSIZE];
};
void main()
{
	static int up_id=-1,down_id=-1;
	struct message *sbuf,*rbuf; 
	key_t key1,key2;
	rbuf=(struct message*)malloc(sizeof(struct message));
	sbuf=(struct message*)malloc(sizeof(struct message));
	key1=ftok("file1.txt",33);
	key2=ftok("file2.txt",34);
	if((up_id=msgget(key1,PERMS))<0){
		perror(" megget "); exit(1);
	}
	if((down_id=msgget(key2,PERMS))<0){
		perror(" megget "); exit(1);
	}
	printf(" Insert message to send to server: ");
	scanf("%[^\n]s",sbuf->mtext);
	sbuf->mtype=getpid();
	if(msgsnd(up_id,sbuf,strlen(sbuf->mtext),0)<0){
		perror(" msgsnd "); exit(1) ;
	}
	if(strcmp(sbuf->mtext,"Quit")==0)
	{
		return;
	}
	if(msgrcv(down_id,rbuf,MSGSIZE,sbuf->mtype,0)<0){
		perror(" msgrcv "); exit(1) ;
	}
	printf(" Processed msg from server: %s\n",rbuf->mtext);
	free(rbuf);
	free(sbuf);
}
