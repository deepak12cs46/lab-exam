/* Roll No:  12/CS/39, 12/CS/40
 * Name:     Soumyadip Mitra, Saikat Kumar Dey
 * Group No: 19 
 */
 
#include<sys/types.h>
#include<sys/ipc.h>
#include<sys/msg.h>
#include<stdio.h>
#include<stdlib.h>
#include<string.h>
#include<time.h>
#define MSGSIZE 256
#define PERMS 0666
struct message {
	long int mtype;
	char mtext[MSGSIZE];
};
void main () 
{
	time_t t;
	static int up_id=-1,down_id=-1;
	int i=0;
	struct message *sbuf,*rbuf;
	key_t key1,key2;
	key1=ftok("file1.txt",33);
	key2=ftok("file2.txt",34);
	if((up_id=msgget(key1,PERMS|IPC_CREAT))<0)
	{
		perror(" megget "); exit(1);
	}
	if((down_id=msgget(key2,PERMS|IPC_CREAT))<0)
	{
		perror(" megget "); exit(1);
	}
	while(1)
	{
		i=0;
		rbuf=(struct message*)malloc(sizeof(struct message));
		sbuf=(struct message*)malloc(sizeof(struct message));
		if(msgrcv(up_id,rbuf,MSGSIZE,0,0)<0){
			perror(" msgrcv "); exit(1);
		}
		if(strcmp(rbuf->mtext,"Quit")==0)
		{
			exit(0);
		}
		time(&t);
		printf(" Message received at time : %s ",ctime(&t));
		printf(" Received message : %s \n",rbuf->mtext);
		while(rbuf->mtext[i]!='\0')
		{	
			if(rbuf->mtext[i]>=65&&rbuf->mtext[i]<=90)
				sbuf->mtext[i]=rbuf->mtext[i]+32;
			else if(rbuf->mtext[i]>=97&&rbuf->mtext[i]<=122)
				sbuf->mtext[i]=rbuf->mtext[i]-32;
			else
				sbuf->mtext[i]=rbuf->mtext[i];
			i++;
		}
		sbuf->mtext[i]='\0';
		sbuf->mtype=rbuf->mtype;
		if(msgsnd(down_id,sbuf,strlen(sbuf->mtext),0)<0){
			perror(" msgsnd "); exit(1);
		}
		printf(" Sent message : %s \n\n",sbuf->mtext);
		free(rbuf);
		free(sbuf);
	}
}
