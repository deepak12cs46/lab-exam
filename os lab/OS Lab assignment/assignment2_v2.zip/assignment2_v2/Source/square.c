/* Roll No:  12/CS/39, 12/CS/40
 * Name:     Soumyadip Mitra, Saikat Kumar Dey
 * Group No: 19 
 */
 
#include <stdio.h>
#include <unistd.h>
#include <stdlib.h>
#include <string.h>
#include "stringop.c"

int main(int argc, char **argv)
{

	printf("PID of %s: %d\n",argv[0],getpid());
	
	if(argc>2)
	{
		//change the number given in the last argument and call from the 2nd element onwards
		int new_num= atoi(argv[argc-1]);
		new_num*=new_num;
		char *s= malloc(sizeof(char)*20);
		toString(new_num,&s);
		strcpy(argv[argc-1],s);
		execvp(argv[1],argv+1);
	}
	else
	{
		int n= atoi(argv[argc-1]);
		printf("RESULT: %d\n",n*n);
	}

}
