/* Roll No:  12/CS/39, 12/CS/40
 * Name:     Soumyadip Mitra, Saikat Kumar Dey
 * Group No: 19 
 */

#include <stdio.h>
#include <unistd.h>
#include <stdlib.h>
#include <string.h>

void reverse(char**);

void toString(int num, char **s)
{
	char *str= *s;
	int tmp= num, i=0;
	while(tmp)
	{
		str[i]= tmp%10 + '0';
		tmp=tmp/10;
		i++;
	}
	str[i]='\0';
	reverse(s);

}


void reverse(char **s)
{
	char *str= *s;
	
	int i=0, j= strlen(str)-1;

	while(i<=j)
	{

		char temp;
		temp = str[i];
		str[i]= str[j];
		str[j]= temp;
		i++, j--;
	}
	str[strlen(str)]='\0';
}
